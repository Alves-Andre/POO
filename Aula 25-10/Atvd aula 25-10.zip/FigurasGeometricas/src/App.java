public class App {
    public static void main(String[] args) throws Exception {

        Retangulo r1 = new Retangulo(10, 12, 4, 5, 2);

        Circulo c1 = new Circulo(10, 15, 3, 6);

        Triangulo t1 = new Triangulo(10, 14, 3, 5, 3, "Equilatero");
    }
}
