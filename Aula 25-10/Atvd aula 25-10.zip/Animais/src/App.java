public class App {
    public static void main(String[] args) throws Exception {
        
        Mamifero macaco = new Mamifero("Macaco", "Macho","Onívoro",4, "Bonito");

        
    }
}
