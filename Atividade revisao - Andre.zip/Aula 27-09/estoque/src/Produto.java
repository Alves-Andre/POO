
public class Produto {
    public String nome;
    public boolean peressivel;
    public Integer quantidade;
    

    public Produto(String nome, boolean peressivel, Integer quantidade) {
        this.nome = nome;
        this.peressivel = peressivel;
        this.quantidade = quantidade;
    }

}
