
public class Livro {
    public String nome;
    public String editora;
    public String datalancamento;
    public String isbn;
    public String idioma;
    public String autor;

    public Livro(){

    }

    public Livro(String nome, String editora, String datalancamento, String isbn, String idioma, String autor) {
        this.nome = nome;
        this.editora = editora;
        this.datalancamento = datalancamento;
        this.isbn = isbn;
        this.idioma = idioma;
        this.autor = autor;
    }

}
