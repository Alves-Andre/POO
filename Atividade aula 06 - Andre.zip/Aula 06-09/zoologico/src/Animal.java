
public class Animal {
    public String nome;
    public String classe;
    public String nomeCientifico;
    public String alimentacao;
    public String habitat;

    public Animal(){

    }

    public Animal(String nome, String classe, String nomeCientifico, String alimentacao, String habitat) {
        this.nome = nome;
        this.classe = classe;
        this.nomeCientifico = nomeCientifico;
        this.alimentacao = alimentacao;
        this.habitat = habitat;
    }

    
}
