class Bicicleta extends Veiculo {
    public Bicicleta(String nome, double velocidadeMedia) {
        super(nome, velocidadeMedia);
    }
}
