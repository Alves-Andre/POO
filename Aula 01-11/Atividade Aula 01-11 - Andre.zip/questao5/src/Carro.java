class Carro extends Veiculo {
    public Carro(String nome, double velocidadeMedia) {
        super(nome, velocidadeMedia);
    }
}
