class Onibus extends Veiculo {
    public Onibus(String nome, double velocidadeMedia) {
        super(nome, velocidadeMedia);
    }
}